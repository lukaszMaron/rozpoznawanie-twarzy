#!/usr/bin/python 
import RPi.GPIO as GPIO 
from subprocess import call 
from datetime import datetime
import time 
import os 
import picamera
import math
from sklearn import neighbors
import os.path
import pickle
from PIL import Image, ImageDraw
import recognition
from recognition import image_files_in_folder
import numpy as np
import sounddevice as sd


callButton = 29 
faceButton = 31
openButton = 33
videoButton = 18
relayPin = 7 
# button debounce time in seconds 
debounceSeconds = 0.01 
GPIO.setmode(GPIO.BOARD) 
GPIO.setup(callButton, GPIO.IN, pull_up_down=GPIO.PUD_UP) 
GPIO.setup(faceButton, GPIO.IN, pull_up_down=GPIO.PUD_UP) 
GPIO.setup(openButton, GPIO.IN, pull_up_down=GPIO.PUD_UP) 
GPIO.setup(videoButton, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(relayPin, GPIO.OUT)
GPIO.output(relayPin, GPIO.LOW)

camera = picamera.PiCamera()
camera.resolution = (320, 240)
output = np.empty((240, 320, 3), dtype=np.uint8) 

doorbellPath = 'dingdong.wav'
 
def openDors():
    GPIO.output(relayPin, GPIO.HIGH)
    time.sleep(5)
    print("Doors open at:",datetime.today().strftime('%Y-%m-%d-%H:%M:%S'))
    GPIO.output(relayPin, GPIO.LOW) 
    return


def predict(X_frame, knn_clf=None, model_path=None, distance_threshold=0.5):

    if knn_clf is None and model_path is None:
        raise Exception("Must point out traindes model path")

    if knn_clf is None:
        with open(model_path, 'rb') as f:
            knn_clf = pickle.load(f)

    X_face_locations = recognition.face_locations(X_frame)

    if len(X_face_locations) == 0:
        return []

    faces_encodings = recognition.face_encodings(X_frame, known_face_locations=X_face_locations)

    closest_distances = knn_clf.kneighbors(faces_encodings, n_neighbors=1)
    are_matches = [closest_distances[0][i][0] <= distance_threshold for i in range(len(X_face_locations))]

    return [(pred, loc) if rec else ("unknown", loc) for pred, loc, rec in zip(knn_clf.predict(faces_encodings), X_face_locations, are_matches)]    

def face_rec():
    process_this_frame = 29
    print('Setting camera')

    
    #camera.start_preview()
    start = time.time()
    fiveSec = 0
    while fiveSec <= 5:
        camera.capture(output, format="rgb")
        predictions = predict(output, model_path="trained_model.clf")
        if predictions:

            if predictions[0][0] != "unknown":
                openDors()
                print("Recognizes ", predictions[0][0], "'s faces")
                #camera.stop_preview()
                return
        fiveSec = time.time() - start

    #camera.stop_preview()
    print('Camera stops')
    return

def callback(indata, outdata, frames, time, status):
    if status:
        print(status)
    outdata[:] = indata

streamPrimo = sd.Stream(device=(0, 1),channels=1,callback=callback )
streamSecondo = sd.Stream(device=(2, 4),channels=1,callback=callback )

while True: 
   
   
    playSound = GPIO.input(callButton)
    openDoor = GPIO.input(openButton)
    chackFace = GPIO.input(faceButton)
    startStopVideo = GPIO.input(videoButton)
    if playSound == False:
        os.system("AUDIODEV=hw:3,0 play "+doorbellPath)

    if chackFace == False:
        face_rec()    

    if openDoor == False:
        openDors()

    if startStopVideo == False:
        run = True
        print("Videochat starts at: ",datetime.today().strftime('%Y-%m-%d-%H:%M:%S'))
        camera.start_preview()
        streamPrimo.start()
        streamSecondo.start()

        while run:
            time.sleep(0.5)
            startStopVideo = GPIO.input(videoButton)
            if startStopVideo == False:
                run = False
                camera.stop_preview()
                streamPrimo.stop()
                streamSecondo.stop()
                print("Videochat ends at: ",datetime.today().strftime('%Y-%m-%d-%H:%M:%S'))
                time.sleep(2)

    time.sleep(0.1) 
